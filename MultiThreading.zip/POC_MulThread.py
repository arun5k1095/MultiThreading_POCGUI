# Tool = "Multi-threading POC"
# Handcraftedby : "AiVolved Pvt Ltd , Bangalore , Dec,2021"
# Version = "1.2"
# LastModifiedOn : "23rd Dec 2021"
# LastModifiedBy = "Arun Kumar , Sr. SW Er." 


#!/usr/bin/python3
# -*- coding: utf-8 -*-


from threading import*
import os
import sys
import time
from PyQt5.QtWidgets import *
from PyQt5 import QtGui


class TaskControlBtn:
    def __init__(self, Cord_X, Cord_Y, Iconname):
        self.button = QPushButton(MainWindowGUI)
        self.button.move(Cord_X, Cord_Y)
        self.button.resize(37, 37)
        self.button.setStyleSheet("background-image: url(DataFiles/Icons/{}.jpg);".format(Iconname));
        self.button.show()



def Thread_1(eventPR=0 , eventSS=0):
    global LCD_Task1,ThreadDetailsT1,Button_Task1,T1TerminateSignal
    while True:
        if MultiThreadingStateFlag:
            eventSS.wait()
        Button_Task1.setStyleSheet("background-color: Green")
        try:
            for counter in range(1,int(T1CountUpto.text().strip())+1):
                if MultiThreadingStateFlag:
                    eventPR.wait()
                    if not eventSS.is_set():
                        LCD_Task1.display(0)
                        break
                LCD_Task1.display(counter)
                ThreadDetailsT1.setText("Thread: {} \nID: {}\n\nCount ↑ {} every {}s".format(current_thread().name,\
                                                                                          get_ident(),\
                                                                                          T1CountUpto.text(),int(T1TimeDelay.text().strip())))
                QApplication.processEvents()
                time.sleep(int(T1TimeDelay.text().strip()))
            T1TerminateSignal.clear()
            Button_Task1.setStyleSheet("background-color: white")
            if not MultiThreadingStateFlag:
                break
        except Exception as error :
            print(error)
            Button_Task1.setStyleSheet("background-color: white")
            
            
def Thread_2(eventPR=0,eventSS=0):
    global LCD_Task2,ThreadDetailsT2,Button_Task2 ,T2TerminateSignal
    while True:
        if MultiThreadingStateFlag:
            eventSS.wait()
        Button_Task2.setStyleSheet("background-color: Green")
        try:
            for counter in range(1,int(T2CountUpto.text().strip())+1):
                if MultiThreadingStateFlag:
                    eventPR.wait()
                    if not eventSS.is_set():
                        LCD_Task2.display(0)
                        break
                LCD_Task2.display(counter)
                ThreadDetailsT2.setText("Thread: {} \nID: {}\n\nCount ↑ {} every {}s".format(current_thread().name, \
                                                                                             get_ident(),
                                                                                             T2CountUpto.text(), int(
                        T2TimeDelay.text().strip())))
                QApplication.processEvents()
                time.sleep(int(T2TimeDelay.text().strip()))
            T2TerminateSignal.clear()
            Button_Task2.setStyleSheet("background-color: white")
            if not MultiThreadingStateFlag:
                break
        except Exception as error :
            print(error)
            Button_Task2.setStyleSheet("background-color: white")
            
            
MultiThreadingStateFlag = 0


def UpdateMultiThreadingState():

    global MultiThreadingStateFlag
    Button_ActivateMulThrd.setText('Active')
    Button_ActivateMulThrd.setStyleSheet("background-color: Green")
    try:
        if MultiThreadingStateFlag:
            pass
        else :
            MultiThreadingStateFlag = 1
    except Exception as error :print(error)
    
    
T1pausedSignal = Event()
T1TerminateSignal = Event()
T2pausedSignal = Event()
T2TerminateSignal = Event()
Task1 = Thread(target=Thread_1,args = (T1pausedSignal,T1TerminateSignal, )) 
Task2 = Thread(target=Thread_2,args = (T2pausedSignal,T2TerminateSignal, )) 


# Shcedule task1 on main thread or initiate a new one
def Arbitrate_Main_Mul_ThreadsT1():
    global T1pausedSignal,T1TerminateSignal
    if MultiThreadingStateFlag:
        if Task1.is_alive() : print("Thread Task is already running")
        # Indicates thead was already initiated previously , hence No action required
        else:
            try:
                Task1.start() #Initiate a new thread
                T1pausedSignal.set()
                T1TerminateSignal.set()
            except :
                T1TerminateSignal.set()
    else:Thread_1()
    
# Shcedule task2 on main thread or initiate a new one
def Arbitrate_Main_Mul_ThreadsT2(): 
    global T2pausedSignal , T2TerminateSignal
    if MultiThreadingStateFlag:
        if Task2.is_alive() : print("Thread Task is already running")

        else:
            try:
                Task2.start()
                T2pausedSignal.set()
                T2TerminateSignal.set()
            except : T2TerminateSignal.set()
    else: Thread_2()
    
# Acquire relative paths of files    
def resource_path(relative_path):  
   try:
        base_path = sys._MEIPASS
   except Exception:
        base_path = os.path.abspath(".")
   return os.path.join(base_path, relative_path)
IconFilepath = resource_path("DataFiles/Icons/AI_Volved.ico")


if __name__ == "__main__":

    Aplication = QApplication(sys.argv)
    MainWindowGUI = QWidget()
    MainWindowGUI.setFixedSize(907, 410)
    MainWindowGUI.setWindowTitle('Multi Threading POC')
    MainWindowGUI.setStyleSheet("background-color: white;")
    MainWindowGUI.setStyleSheet("background-image: url(DataFiles/Icons/Wallpaper.jpg);");
    MainWindowGUI.setWindowIcon(QtGui.QIcon(IconFilepath))
    LCD_Task1 = QLCDNumber(MainWindowGUI)
    LCD_Task2 = QLCDNumber(MainWindowGUI)
    LCD_Task1.setStyleSheet("color: rgb(20, 114, 175)")
    LCD_Task2.setStyleSheet("color: rgb(20, 114, 175)")
    LCD_Task1.setFixedSize(120,80)
    LCD_Task2.setFixedSize(120,80)
    LCD_Task1.display("0000")
    LCD_Task2.display("0000")
    LCD_Task1.move(400, 90)
    LCD_Task2.move(550, 90)
    label = QLabel(MainWindowGUI)
    label.setText("Multithread Process :")
    label.move(10, 50)
    label.show()
    
    label2 = QLabel(MainWindowGUI)
    label2.setText("Initiate :")
    label2.move(320, 50)
    label2.show()
    
    T1CountUpto = QLabel(MainWindowGUI)
    T1CountUpto.setText("Count Upto :")
    T1CountUpto.move(318, 320)
    T1CountUpto.show()
    
    T1CountUpto = QLineEdit(MainWindowGUI)
    T1CountUpto.move(400,320)
    T1CountUpto.resize(120, 25)
    T1CountUpto.setText("15")
    
    T1TimeDelay = QLabel(MainWindowGUI)
    T1TimeDelay.setText("Time delay :")
    T1TimeDelay.move(318, 360)
    T1TimeDelay.show()
    T1TimeDelay = QLineEdit(MainWindowGUI)
    T1TimeDelay.move(400, 357)
    T1TimeDelay.resize(120, 25)
    T1TimeDelay.setText("1")
    
    T2CountUpto = QLineEdit(MainWindowGUI)
    T2CountUpto.move(550,320)
    T2CountUpto.resize(120, 25)
    T2CountUpto.setText("21")
    
    T2TimeDelay = QLineEdit(MainWindowGUI)
    T2TimeDelay.move(550, 357)
    T2TimeDelay.resize(120, 25)
    T2TimeDelay.setText("3")
    
    EntryRandom = QLineEdit(MainWindowGUI)
    EntryRandom.move(720,50)
    EntryRandom.resize(180, 100)
    EntryRandom.setText("Type here...")

    def RandomTextUpdate():
        global RandomEntryDetails
        RandomEntryDetails.setText("Thread : {}\nID: {}\nText: {}".format(current_thread()\
        .name, get_ident(),EntryRandom.text() ))
        
    EntryRandom.textChanged.connect(RandomTextUpdate)
    RandomEntryDetails = QLabel(MainWindowGUI)
    RandomEntryDetails.setText("Thread : {}\nID: {}".format(current_thread().name,get_ident()))
    RandomEntryDetails.move(720, 152)
    RandomEntryDetails.setStyleSheet("color: rgb(20, 114, 175)")
    RandomEntryDetails.resize(180, 100)
    RandomEntryDetails.show()
    
    ThreadDetailsT1 = QLabel(MainWindowGUI)
    ThreadDetailsT1.setText("Thread: NA \nID: NA\n\nCount ↑ {} every {}s".format(T1CountUpto.text(),T1TimeDelay.text()))
    ThreadDetailsT1.move(400, 180)
    ThreadDetailsT1.setStyleSheet("color: rgb(20, 114, 175)")
    ThreadDetailsT1.resize(150, 70)
    ThreadDetailsT1.show()
    
    ThreadDetailsT2 = QLabel(MainWindowGUI)
    ThreadDetailsT2.setText("Thread: NA \nID: NA\n\nCount ↑ {} every {}s".format(T2CountUpto.text(),T2TimeDelay.text()))
    ThreadDetailsT2.move(550, 180)
    ThreadDetailsT2.setStyleSheet("color: rgb(20, 114, 175)")
    ThreadDetailsT2.resize(150, 70)
    ThreadDetailsT2.show()
    
    Button_ActivateMulThrd = QPushButton(MainWindowGUI)
    Button_ActivateMulThrd.setText('Inactive')
    Button_ActivateMulThrd.move(150, 45)
    Button_ActivateMulThrd.show()
    Button_ActivateMulThrd.resize(100, 35)
    Button_ActivateMulThrd.clicked.connect(UpdateMultiThreadingState)
    Button_ActivateMulThrd.setStyleSheet("background-color: red")
    
    Button_Task1 = QPushButton(MainWindowGUI)
    Button_Task1.setText('Task 1 : Thread')
    Button_Task1.move(400, 45)
    Button_Task1.resize(120, 35)
    Button_Task1.setStyleSheet("background-color: 	Pale gray")
    Button_Task1.show()
    Button_Task1.clicked.connect(Arbitrate_Main_Mul_ThreadsT1)
    
    Button_Task2 = QPushButton(MainWindowGUI)
    Button_Task2.setText('Task 2 : Thread')
    Button_Task2.move(550, 45)
    Button_Task2.resize(120, 35)
    Button_Task2.setStyleSheet("background-color: 	Pale gray")
    Button_Task2.show()
    Button_Task2.clicked.connect(Arbitrate_Main_Mul_ThreadsT2)
    T1ButtonPause = TaskControlBtn(400,260,"Pause")
    
    def T1Paused():
        global T1pausedSignal
        T1pausedSignal.clear()
        
    T1ButtonPause.button.clicked.connect(T1Paused)
    T1ButtonResume = TaskControlBtn(440,260,"Resume")
    
    def T1Resume():
        global T1pausedSignal,T1TerminateSignal
        T1pausedSignal.set()
        T1TerminateSignal.set()
        
    T1ButtonResume.button.clicked.connect(T1Resume)
    T1ButtonStop = TaskControlBtn(480,260,"Stop")
    
    def T1Stop():
        T1TerminateSignal.clear()
        
    T1ButtonStop.button.clicked.connect(T1Stop)
    T2ButtonPause = TaskControlBtn(550,260,"Pause")
    def T2Paused():
        global T2pausedSignal
        T2pausedSignal.clear()
    T2ButtonPause.button.clicked.connect(T2Paused)
    T2ButtonResume = TaskControlBtn(590,260,"Resume")
    
    def T2Resume():
        global T2pausedSignal,T2TerminateSignal
        T2pausedSignal.set()
        T2TerminateSignal.set()
        
    T2ButtonResume.button.clicked.connect(T2Resume)
    T2ButtonStop = TaskControlBtn(630,260,"Stop")
    
    def T2Stop():
        global T2TerminateSignal
        T2TerminateSignal.clear()
        
    T2ButtonStop.button.clicked.connect(T2Stop)
    MainWindowGUI.show()
    sys.exit(Aplication.exec_())